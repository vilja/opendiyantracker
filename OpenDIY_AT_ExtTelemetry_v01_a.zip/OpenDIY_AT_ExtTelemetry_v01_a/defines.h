// GPS flags
// ---------
//GPS_update
#define GPS_NONE 0
#define GPS_POSITION 1
#define GPS_HEADING 2

//GPS_fix
#define VALID_GPS 0x00
#define BAD_GPS 0x01
#define FAILED_GPS 0x03

//PWM setup
//-----------
#define Xtalfrequency 16000000
#define pulse_one 500  //800
#define pulse_zero 250  //450

#define PI 3.14159265

//1-2
#define REVERSE_ROLL -1			//To reverse roll, PUT -1 to reverse it
//1-3
#define REVERSE_PITCH 1			//To reverse pitch, PUT -1 to reverse it
#define CH1_MIN 1000 		// (Microseconds) Range of Ailerons/ Rudder
//3-5
#define CH1_MAX 2000 		// (Microseconds)
//3-6
#define CH2_MIN 1000 		// (Microseconds) Range of Elevator
//3-7
#define CH2_MAX 2000 		// (Microseconds)


#define WP_START_BYTE 0x18		// where in memory home WP is stored + all other WP
#define WP_10_BYTES 10


